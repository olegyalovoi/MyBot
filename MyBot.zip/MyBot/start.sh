#!/bin/bash
python3 MyBot.py

